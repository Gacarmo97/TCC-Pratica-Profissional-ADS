export const secret = 'secret'
//registrando secret do controllers/user.ts
/**@author Raquel K. Alves*/