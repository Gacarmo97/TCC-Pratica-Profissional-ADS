export interface ColumnInputInterface {
    title: string;
    boardId: string;
  }
  
  /**@author Raquel K. Alves*/