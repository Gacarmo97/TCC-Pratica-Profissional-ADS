export interface TaskInputInterface {
  title: string;
  columnId: string;
  boardId: string;
}

/**@author Raquel K. Alves*/