export interface TaskInterface {
  id: string;
  title: string;
  description?: string;
  columnId: null;
  boardId: string;
  userId: string;
}

/**@author Raquel K. Alves*/