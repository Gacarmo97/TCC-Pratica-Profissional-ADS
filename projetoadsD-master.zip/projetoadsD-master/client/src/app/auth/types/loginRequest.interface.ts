export interface LoginRequestInterface {
    email: string | null;
    password: string | null;
  }
  //interface de login
  /**@author Raquel K. Alves*/