export interface CurrentUserInterface {
    id: string;
    token: string;
    username: string;
    email: string;
  }
//criando a interface para o currentUser
/**@author Raquel K. Alves*/