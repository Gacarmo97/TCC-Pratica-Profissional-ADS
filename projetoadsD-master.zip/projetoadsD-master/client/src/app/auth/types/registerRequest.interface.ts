export interface RegisterRequestInterface {
    email: string | null;
    username: string | null;
    password: string | null;
}

/**@author Raquel K. Alves*/