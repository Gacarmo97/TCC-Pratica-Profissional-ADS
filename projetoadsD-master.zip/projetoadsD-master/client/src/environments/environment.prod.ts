export const environment = {
    production: true,
    apiUrl: 'http://projetoads.com/api',
    socketUrl: 'http://projetoads.com',
  };

  /**@author Raquel K. Alves*/
  